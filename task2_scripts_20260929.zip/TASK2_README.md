# Task 2 — Quantitative testing / regression workflow

This bundle is designed for the current `textual-analysis` project and follows the group's DOCX/PDF methodology.

## Locked methodology

1. **Text score**
   - Negation rule: do not count a positive/negative word when `not`, `no`, or `never` appears within the preceding 3 words.
   - Proportional weighting:
     - `Pos_i = sum(F_i,j for positive words) / A_i`
     - `Neg_i = sum(F_i,j for negative words) / A_i`
     - `Tone_i = (Pos_i - Neg_i)/(Pos_i + Neg_i)` (or `Pos_i - Neg_i`, both definitions retained in the existing tone output).
   - TF-IDF is retained for the dictionary comparison.

2. **Event study**
   - Event day `tau = 0` = filing/announcement date used by the current pipeline.
   - Estimation window `[-244,-6]` = 239 trading observations.
   - Event windows: `[-1,+1]`, `[0,+3]`, `[-3,+3]`, `[-5,+5]`.
   - Market model: `R_i,t = alpha_i + beta_i R_m,t + epsilon_i`.
   - Abnormal return: `AR_i,t = R_i,t - alpha_hat_i - beta_hat_i R_m,t`.
   - CAR is the sum of AR in the selected event window.
   - Existing event-study output is reused; this bundle does not replace it.

3. **Controls**
   - `Size = ln(market capitalization)` at the end of the month **before** the 10-K filing.
   - `BM = book equity / market capitalization` at fiscal year-end (`report_date`).
   - `Volatility = SD(idiosyncratic residuals)` from a market model using up to 60 months of pre-filing daily data.
   - `Turnover = ln(mean(daily volume / shares outstanding))` over event-relative days `[-252,-6]`.
   - EADRet is not invented because the current filing index does not provide a verified prior earnings-announcement date. The script records this explicitly. Accruals is not used in the primary four-control model in this phase.

4. **Regression**
   - C1: `CAR_i = a + b*Score_i + epsilon_i` (baseline).
   - C2: `CAR_i = a + b*Score_i + controls_i + epsilon_i`.
   - C3: `CAR_i = a + b*Positive_i + c*Negative_i + controls_i + epsilon_i`.
   - C4: `CAR_i = a + b*Score_LM_i + c*Score_Harvard_i + epsilon_i`, run separately for proportional and TF-IDF scoring.

5. **Diagnostics**
   - Pearson correlation matrix.
   - VIF for multicollinearity.
   - Breusch–Pagan and White tests for heteroskedasticity.
   - OLS SE, HC3 robust SE, and firm-clustered SE.
   - Baseline vs C2 comparison of coefficient, HC3 SE, p-value, R-squared and N.
   - Directional one-sided tests: H1 requires Positive coefficient `> 0`; H2 requires Negative coefficient `< 0`.

## Run order (Git Bash)

Do not type the `$` prompt shown in examples.

```bash
python -m pip install -U pandas numpy requests statsmodels
python src/build_controls_final.py --max-tickers 3
python src/build_controls_final.py
python src/regression_analysis_final.py
```

For the full run, the controls script fetches/caches SEC company facts. Set a proper SEC user-agent first when possible:

```bash
export SEC_USER_AGENT="Your Name your_email@example.com"
```

Expected control outputs:

- `data/metadata/controls/controls_item7.csv`
- `data/metadata/controls/control_qa.csv`
- `data/metadata/controls/sec_facts_cache/`

Expected regression outputs:

- `data/metadata/regression_analysis/regression_sample.csv`
- `data/metadata/regression_analysis/regression_results.csv`
- `data/metadata/regression_analysis/regression_diagnostics.csv`
- `data/metadata/regression_analysis/baseline_vs_full.csv`
- `data/metadata/regression_analysis/vif_results.csv`
- `data/metadata/regression_analysis/correlation_results.csv`
- `data/metadata/regression_analysis/hypothesis_tests.csv`

The current environment cannot execute the user's local Git repository, so the full 100-firm run must be launched from the project's Git Bash/VS Code terminal.
